package com.company.flightSearch.service;

import java.sql.Date;
import java.util.List;

import com.company.flightSearch.dto.FlightResponseDto;
import com.company.flightSearch.dto.FlightSeatResponseDto;
import com.company.flightSearch.model.Flight;

public interface FlightService {

	List<FlightResponseDto>   searchFlights(String source, String destination, Date date);

	List<FlightResponseDto> searchFlightsByName( String name);

	List<FlightResponseDto> searchFlightsByCost(double cost);

	FlightSeatResponseDto checkAvailability(int flightId);

	String getAirportName(String location);

}
