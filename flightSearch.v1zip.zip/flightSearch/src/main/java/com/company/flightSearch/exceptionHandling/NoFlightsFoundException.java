package com.company.flightSearch.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
 
@ResponseStatus(HttpStatus.NOT_FOUND)
public class NoFlightsFoundException extends RuntimeException {
	 public NoFlightsFoundException(String exception) {
	        super(exception);
	    }
}
