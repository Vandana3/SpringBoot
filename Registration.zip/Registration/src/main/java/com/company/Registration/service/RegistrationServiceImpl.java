package com.company.Registration.service;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.company.Registration.dao.UserRepository;
import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.exceptionHandling.InvalidLoginException;
import com.company.Registration.model.User;
import com.company.Registration.responseContract.ResponseContract;

@Service
public class RegistrationServiceImpl implements RegistrationService{
@Autowired 
UserRepository userRepository;

@Autowired
ModelMapper modelMapper;
static int id=1001;
	@Override
	public ResponseEntity<Object> saveUser(UserRequestDto userRequestDto) {
		User user = new User();
		modelMapper.getConfiguration()
        .setMatchingStrategy(MatchingStrategies.STRICT);
		user=modelMapper.map(userRequestDto,User.class);
		user.setUserId(id++);
		userRepository.save(user);
		
		HttpStatus status;
		status=HttpStatus.OK;
		ResponseContract response = new ResponseContract("Successfully registered",status.value(),user.getUserId());
		return new ResponseEntity<>(response,HttpStatus.OK);
		
	}
	@Override
	public ResponseEntity<Object> validate(String name, String password) {
		User user = new User();
		user=userRepository.findUserByNameAndPassword(name,password);
		if(user==null) { throw new InvalidLoginException("Invalid login");}
		HttpStatus status;
		status=HttpStatus.OK;
		ResponseContract response = new ResponseContract("Successfull login",status.value());
		return new ResponseEntity<>(response,HttpStatus.OK);
		
		
	}
	

}
