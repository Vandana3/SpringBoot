package com.company.Registration.exceptionHandling;

import java.time.LocalDate;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
 
@XmlRootElement(name = "error")
public class ErrorResponse 
{
	 public String message;
	 public LocalDate date;
	 public int status;
     public ErrorResponse(String message, int status, LocalDate date) {
        
        this.message = message;
        this.status=status;
        this.date = date;
    }

}
