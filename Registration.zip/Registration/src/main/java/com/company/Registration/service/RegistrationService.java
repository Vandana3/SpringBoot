package com.company.Registration.service;

import org.springframework.http.ResponseEntity;

import com.company.Registration.dto.UserRequestDto;
import com.company.Registration.model.User;

public interface RegistrationService {

	ResponseEntity<Object> saveUser(UserRequestDto userRequestDto);

	ResponseEntity<Object>  validate(String name, String password);

	
}
