package com.example.Employee.service;

import java.util.List;
import java.util.Optional;

import com.example.Employee.dto.EmployeeRequestDto;
import com.example.Employee.model.Employee;

public interface EmployeeService {
public void saveEmployee(EmployeeRequestDto employeeRequestDto);

public Optional<Employee> getEmployeeDetails(long sapId);
public Iterable<Employee> getAllEmployeeDetails();

List<Employee> getEmployeeBySalary(double salary);
}
