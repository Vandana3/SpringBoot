package com.example.Employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Employee.dao.EmployeeRepository;
import com.example.Employee.dao.OrganisationRepository;
import com.example.Employee.dto.EmployeeRequestDto;
import com.example.Employee.exceptionHandling.NoEmployeeFoundException;
import com.example.Employee.helper.ServiceHelper;
import com.example.Employee.model.Employee;
import com.example.Employee.model.Organisation;

@Service
public class EmployeeServiceImpl implements EmployeeService{
@Autowired 
EmployeeRepository employeeRepository;

@Autowired 
OrganisationRepository organisationRepository;

	/* Saving employee details */
	@Override
	public void saveEmployee(EmployeeRequestDto employeeRequestDto) {
		Employee employee = new Employee();
		employee.setAddress(employeeRequestDto.getAddress());
		employee.setDateOfBirth(employeeRequestDto.getDateOfBirth());
		employee.setEmail(employeeRequestDto.getEmail());
		employee.setName(employeeRequestDto.getName());
		employee.setPhoneNumber(employeeRequestDto.getPhoneNumber());
		employee.setSapId(ServiceHelper.getSapId());
		employeeRepository.save(employee);
	}
	
	/* Getting all employee details */
	@Override
	public Iterable<Employee> getAllEmployeeDetails() {
		return employeeRepository.findAll();
	}

	/* Getting employee details by id */
	@Override
	public Optional<Employee> getEmployeeDetails(long sapId) {
		return employeeRepository.findById(sapId);
		
	}
	/* Getting employee details by salary */
	@Override
	public List<Employee> getEmployeeBySalary(double salary) {
		Employee employee = new Employee();
		List<Employee> employeeList= new ArrayList<Employee>();
		Iterable<Organisation> org=organisationRepository.findBySalaryGreaterThanEqual(salary);
		for(Organisation organisation:org) {
			Optional<Employee>employees=employeeRepository.findById(organisation.getSapId());
			employee=employees.get();
			employeeList.add(employee);
		}
		 if(employeeList.isEmpty()) throw new NoEmployeeFoundException("No employee having salary greater than given salary found");
		 
		return employeeList;
	}

}
