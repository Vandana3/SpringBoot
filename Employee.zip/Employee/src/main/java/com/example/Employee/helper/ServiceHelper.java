package com.example.Employee.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.stereotype.Component;
@Component
public class ServiceHelper {
	static long sapId=10001;
	public static double getSalary(){
		List<Double> ls = new ArrayList<Double>();
		ls.add(30000.00);
		ls.add(40000.00);
		ls.add(35000.00);
		Random rand = new Random(); 
	    return ls.get(rand.nextInt(ls.size()));
	}
	
	public static String getProjectName(){
		
		List<String> ls = new ArrayList<String>();
		ls.add("P001");
		ls.add("P002");
		ls.add("P003");
		Random rand = new Random(); 
	    return ls.get(rand.nextInt(ls.size())); 
		
	}
public static String getDesignation(){
		
		List<String> ls = new ArrayList<String>();
		ls.add("Java Trainee");
		ls.add("UI Trainee");
		Random rand = new Random(); 
	    return ls.get(rand.nextInt(ls.size())); 
		
	}

public static String getMailId(String name) {
	
	return name+"@hcl.com";
}

public static Long getSapId() {
	return sapId++;
}
}
