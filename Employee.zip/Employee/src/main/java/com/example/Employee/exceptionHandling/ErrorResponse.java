package com.example.Employee.exceptionHandling;

import java.time.LocalDate;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;
 
@XmlRootElement(name = "error")
public class ErrorResponse 
{
	 public String message;
	 public LocalDate date;
     public ErrorResponse(String message, LocalDate date) {
        
        this.message = message;
        this.date = date;
    }

}
