package com.example.Employee.service;

import java.util.List;

import com.example.Employee.dto.EmployeeRequestDto;
import com.example.Employee.model.Employee;

public interface OrganisationService {
	
public void saveOrganisationDetails(EmployeeRequestDto employeeRequestDto);

}
