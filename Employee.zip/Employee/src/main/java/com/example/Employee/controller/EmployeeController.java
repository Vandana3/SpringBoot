package com.example.Employee.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.Employee.dto.EmployeeRequestDto;
import com.example.Employee.model.Employee;
import com.example.Employee.service.EmployeeService;
import com.example.Employee.service.OrganisationService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	@Autowired
	OrganisationService organisationService;
	
	/* Saving employee details */
	@PostMapping("/employee")
	public void saveEmployee(@RequestBody EmployeeRequestDto employeeRequestDto) {
		employeeService.saveEmployee(employeeRequestDto);
		organisationService.saveOrganisationDetails(employeeRequestDto);
	}

	/* Getting employee details */
	@GetMapping("/employee")
	public Iterable<Employee> getAllEmployee() {
		return employeeService.getAllEmployeeDetails();
	}
	
	/* Getting employee details of particular id */
	@GetMapping("/employee/{sapId}")
	public Optional<Employee> getEmployee( @PathVariable("sapId")long sapId) {
		return employeeService.getEmployeeDetails(sapId);
	}

	/* Getting employee by salary */
	@GetMapping("/employee/salary")
	public List<Employee> getEmployeeBySalary(@RequestParam("salary")double salary) {
		List<Employee> employee= new ArrayList<Employee>();
		employee=employeeService.getEmployeeBySalary(salary);
		return employee;
	}

	
	
}
