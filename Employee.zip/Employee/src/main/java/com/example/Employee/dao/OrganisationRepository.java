package com.example.Employee.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.Employee.model.Organisation;
@Repository
public interface OrganisationRepository extends CrudRepository<Organisation,Long> {

	Iterable<Organisation> findBySalaryGreaterThanEqual(double salary);

}
