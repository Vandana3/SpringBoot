package com.example.Employee.model;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Organisation {
@Id
Long sapId;
String designation;
double salary;
Date dateOfJoining;
String companyMailId;
String projectName;
public Long getSapId() {
	return sapId;
}
public void setSapId(Long sapId) {
	this.sapId = sapId;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public Date getDateOfJoining() {
	return dateOfJoining;
}
public void setDateOfJoining(Date dateOfJoining) {
	this.dateOfJoining = dateOfJoining;
}
public String getCompanyMailId() {
	return companyMailId;
}
public void setCompanyMailId(String companyMailId) {
	this.companyMailId = companyMailId;
}
public String getProjectName() {
	return projectName;
}
public void setProjectName(String projectName) {
	this.projectName = projectName;
}

}
