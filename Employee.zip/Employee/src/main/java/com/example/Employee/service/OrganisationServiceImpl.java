package com.example.Employee.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Employee.dao.EmployeeRepository;
import com.example.Employee.dao.OrganisationRepository;
import com.example.Employee.dto.EmployeeRequestDto;
import com.example.Employee.helper.ServiceHelper;
import com.example.Employee.model.Employee;
import com.example.Employee.model.Organisation;

@Service
public class OrganisationServiceImpl implements OrganisationService {


	@Autowired
	OrganisationRepository organisationRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	/* Saving organisation details */
	@Override
	public void saveOrganisationDetails(EmployeeRequestDto employeeRequestDto) {
		
		Employee employee = new Employee();
	    Organisation organisation = new Organisation();
	    employee=employeeRepository.findByNameAndDateOfBirth(employeeRequestDto.getName(),employeeRequestDto.getDateOfBirth());
	    
	    organisation.setDateOfJoining(employeeRequestDto.getDateOfJoining());
	    organisation.setDesignation(ServiceHelper.getDesignation());
	    organisation.setProjectName(ServiceHelper.getProjectName());
	    organisation.setSalary(ServiceHelper.getSalary());
	    organisation.setSapId(employee.getSapId());
	    organisation.setCompanyMailId(ServiceHelper.getMailId(employeeRequestDto.getName()));
		organisationRepository.save(organisation);
	}

	
	

		    

}
