package com.example.Employee.exceptionHandling;

import java.time.LocalDate;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class ExceptionController {
	
	   @ExceptionHandler(value = NoEmployeeFoundException.class)
	   public ResponseEntity<Object> exception(NoEmployeeFoundException exception) {
		   String message=exception.getMessage();
	       ErrorResponse error = new ErrorResponse(message, LocalDate.now());
	       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	      
	   }
	}
