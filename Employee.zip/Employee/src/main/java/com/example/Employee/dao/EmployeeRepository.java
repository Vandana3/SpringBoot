package com.example.Employee.dao;

import java.sql.Date;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.Employee.model.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee,Long>{

	Employee findByNameAndDateOfBirth(String name, Date dateOfBirth);

}
