package com.company.flightSearch.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.flightSearch.dao.CategoryRepository;
import com.company.flightSearch.dao.FlightRepository;
import com.company.flightSearch.dto.FlightResponseDto;
import com.company.flightSearch.exceptionHandling.NoFlightsFoundExeption;
import com.company.flightSearch.model.Category;
import com.company.flightSearch.model.Flight;



@Service
public class FlightServiceImpl implements FlightService{
@Autowired
FlightRepository flightRepository;

@Autowired
CategoryRepository categoryRepository;

@Autowired 
ModelMapper modelMapper;
	@Override
	public List<FlightResponseDto>  searchFlights(String source, String destination, Date date) {
		
		Category category= new Category();
		FlightResponseDto flightResponseDto = new FlightResponseDto();
		List<FlightResponseDto> flightList=new ArrayList<FlightResponseDto>();
		
		modelMapper.getConfiguration()
        .setMatchingStrategy(MatchingStrategies.STRICT);
		Iterable<Flight> flightIterable=flightRepository.findFlightBySourceAndDestinationAndDate(source,destination,date);
		if(!flightIterable.iterator().hasNext()) {
			throw new NoFlightsFoundExeption("No flights available");
		}
		
		for(Flight flight:flightIterable) {
			java.util.Optional<Category> optionalCategory=categoryRepository.findById(flight.getFlightId());
			//if(!optionalCategory.isPresent()) {}
			category=optionalCategory.get();
			flightResponseDto=modelMapper.map(flight,FlightResponseDto.class);
			/*
			 * modelMapper.map(category,flightResponseDto);
			 * flightList.add(flightResponseDto);
			 */
			flightResponseDto.setBusinessCost(category.getBusinessCost());
			flightResponseDto.setBusinessSeats(category.getBusinessSeats());
			flightResponseDto.setEconomyCost(category.getEconomyCost());
			flightResponseDto.setEconomySeats(category.getEconomySeats());
			 flightList.add(flightResponseDto);
		}
		
		return flightList;
		
	}
	@Override
	public List<FlightResponseDto> searchFlightsByName(List<FlightResponseDto> flightList, String name) {
		
		System.out.println(flightList);
		List<FlightResponseDto> newFlightList=flightList.stream().
				filter(flight->flight.name.equals(name))
				.collect(Collectors.toList());
		
		return newFlightList;
	}

}
