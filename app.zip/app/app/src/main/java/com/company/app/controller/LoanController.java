package com.company.app.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.app.model.Loan;
import com.company.app.service.LoanService;

@RestController
public class LoanController {
@Autowired
LoanService loanService;

	/* Getting loan options for given salary */
	@GetMapping("/loan")
	public List<Loan> getLoan(@RequestParam("salary")double salary) {
		System.out.println(salary);
		List<Loan> loanList=new ArrayList<Loan>();
		loanList=loanService.getLoanDetails(salary);
		return loanList;
		
	}
}
