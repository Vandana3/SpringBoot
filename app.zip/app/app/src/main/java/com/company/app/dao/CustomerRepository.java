package com.company.app.dao;

import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.app.model.Customer;

@Repository
public interface CustomerRepository extends CrudRepository<Customer,Integer>  {

	/*
	 * @Query("From BankCustomer where name=:name and password=:password") public
	 * BankCustomer getBankCustomerByNameAndPassword(@PathParam("name")String
	 * name,@PathParam("password") String password);
	 */
	public Customer findNameByCustomerId(Integer customerId);

	public Customer findBankCustomerByNameAndPassword(String name, String password);

	public Customer findCustomerIdByName(String name);
	
	
	
}
