package com.company.app.model;


import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class CompositeId implements Serializable  {
String fromAccountNumber;
String beneficiaryAccountNumber;


public String getFromAccountNumber() {
	return fromAccountNumber;
}
public void setFromAccountNumber(String fromAccountNumber) {
	this.fromAccountNumber = fromAccountNumber;
}
public String getBeneficiaryAccountNumber() {
	return beneficiaryAccountNumber;
}
public void setBeneficiaryAccountNumber(String beneficiaryAccountNumber) {
	this.beneficiaryAccountNumber = beneficiaryAccountNumber;
}


}


