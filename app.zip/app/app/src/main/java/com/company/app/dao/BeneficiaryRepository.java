package com.company.app.dao;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.app.model.Beneficiary;
import com.company.app.model.CompositeId;

@Repository
public interface BeneficiaryRepository extends CrudRepository<Beneficiary,CompositeId> {

	

}
