package com.company.app.service;

import com.company.app.Dto.CustomerRequestDto;
import com.company.app.model.Customer;

public interface AccountService {
	public void saveBalance(String accountNumber,double balance);
	public void saveAccount(CustomerRequestDto customerRequestDto);
}
