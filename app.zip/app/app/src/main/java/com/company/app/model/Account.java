package com.company.app.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {
@Id
Integer customerId;
String accountNumber;
double balance;
public Integer getCustomerId() {
	return customerId;
}
public void setCustomerId(Integer customerId) {
	this.customerId = customerId;
}
public String getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}

}
