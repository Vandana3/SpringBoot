package com.company.app.service;

import java.util.HashMap;
import java.util.List;

import com.company.app.model.Loan;

public interface LoanService {

	List<Loan> getLoanDetails(double salary);

}
