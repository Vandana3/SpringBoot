package com.company.app.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.app.dao.LoanRepository;
import com.company.app.exceptionHandling.NoLoanOptionAvailableException;
import com.company.app.model.Loan;

@Service
public class LoanServiceImpl implements LoanService{
@Autowired 
LoanRepository loanRepository;

	/* Getting loan details for given salary */
	@Override
	public  List<Loan> getLoanDetails(double salary) {
		Iterable<Loan>loanList=loanRepository.findAll();
		List<Loan> loans= new ArrayList<Loan>();
		double emi=0,rateOfInterest=0,tenure=0;
		long principle=0;
		for(Loan loan:loanList) {
			rateOfInterest=loan.getInterest();
			principle=loan.getPrinciple();
			tenure=loan.getTenure();
			emi=principle*tenure*rateOfInterest/100;
			emi=emi/12;
			if(((salary*60)/100)>emi) {
				loans.add(loan);
			}
		}
		if(loans.isEmpty()) throw new NoLoanOptionAvailableException("No loan option available for given salary");
		return loans;
	}
}
