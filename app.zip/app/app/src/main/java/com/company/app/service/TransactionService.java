package com.company.app.service;

import com.company.app.Dto.TransactionRequestDto;

public interface TransactionService {
public void saveTransaction(TransactionRequestDto transactionRequestDto);
}
