package com.company.app.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
 
@ResponseStatus(HttpStatus.NOT_FOUND)
public class InsufficientBalanceException extends RuntimeException {
	 public InsufficientBalanceException(String exception) {
	        super(exception);
	    }
}
