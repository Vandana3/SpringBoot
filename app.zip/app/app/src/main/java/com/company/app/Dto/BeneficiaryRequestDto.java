package com.company.app.Dto;

import org.springframework.stereotype.Component;

@Component
public class BeneficiaryRequestDto {
String fromAccountNumber;
String toAccountNumber;
String name;
public String getFromAccountNumber() {
	return fromAccountNumber;
}
public void setFromAccountNumber(String fromAccountNumber) {
	this.fromAccountNumber = fromAccountNumber;
}
public String getToAccountNumber() {
	return toAccountNumber;
}
public void setToAccountNumber(String toAccountNumber) {
	this.toAccountNumber = toAccountNumber;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

}
