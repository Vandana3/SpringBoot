package com.company.app.dao;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.company.app.model.Account;
import com.company.app.model.Customer;

public interface AccountRepository extends CrudRepository<Account,Integer>{

	public Account findBalanceByAccountNumber(String fromAccountNumber);
	public Account findByAccountNumber(String accountNumber);
}
