package com.company.app.service;

import com.company.app.Dto.CustomerRequestDto;
import com.company.app.model.Account;
import com.company.app.model.Customer;

public interface CustomerService {
public Iterable<Customer> getCustomerDetails();
public void saveCustomer(CustomerRequestDto customerRequestDto);
public void validateCustomer(String name, String password);


}
