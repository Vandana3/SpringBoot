package com.company.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.company.app.Dto.BeneficiaryRequestDto;
import com.company.app.service.BeneficiaryService;
@RestController
public class BeneficiaryController {
	@Autowired
	BeneficiaryService beneficiaryService;
	
	/* Adding beneficiary */
	@PostMapping("/payee")
	public void addPayee(@RequestBody BeneficiaryRequestDto beneficiaryRequestDto ) {
		beneficiaryService.addPayee(beneficiaryRequestDto);
	}
}
