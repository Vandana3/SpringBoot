package com.company.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import com.company.app.Dto.BeneficiaryRequestDto;
import com.company.app.dao.AccountRepository;
import com.company.app.dao.BeneficiaryRepository;
import com.company.app.exceptionHandling.AccountNotFoundException;
import com.company.app.exceptionHandling.PayeeAlreadyExistsException;
import com.company.app.model.Account;
import com.company.app.model.Beneficiary;
import com.company.app.model.CompositeId;
@Service
public class BeneficiaryServiceImpl implements BeneficiaryService{
@Autowired
AccountRepository accountRepository;

@Autowired
BeneficiaryRepository beneficiaryRepository;
	@Override
	
	/* Adding beneficiaries for a customer */
	public void addPayee(BeneficiaryRequestDto beneficiaryRequestDto) {
		
		Account fromBankAccount = new Account();
		Account toBankAccount = new Account();
		
		String fromAccountNumber=beneficiaryRequestDto.getFromAccountNumber();
		String toAccountNumber=beneficiaryRequestDto.getToAccountNumber();
		fromBankAccount=accountRepository.findByAccountNumber(fromAccountNumber);
		toBankAccount=accountRepository.findByAccountNumber(toAccountNumber);
		if(fromBankAccount==null||toBankAccount==null) {
			throw new AccountNotFoundException("No valid Account");
			}
		
		CompositeId compositeId= new CompositeId();
		compositeId.setBeneficiaryAccountNumber(toAccountNumber);
		compositeId.setFromAccountNumber(fromAccountNumber);
		if(beneficiaryRepository.findById(compositeId).isPresent()) {
			throw new PayeeAlreadyExistsException("Payee already exists");
			}
		Beneficiary beneficiary= new Beneficiary();
		beneficiary.setId(compositeId);
		beneficiary.setBeneficiaryName(beneficiaryRequestDto.getName());
		
		beneficiaryRepository.save(beneficiary);
		
	}

}
