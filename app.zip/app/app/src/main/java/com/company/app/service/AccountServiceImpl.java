package com.company.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.app.Dto.CustomerRequestDto;
import com.company.app.dao.AccountRepository;
import com.company.app.dao.CustomerRepository;
import com.company.app.model.Account;
import com.company.app.model.Customer;

@Service
public class AccountServiceImpl implements AccountService{
	static int accountNumber=123450;
	@Autowired
	AccountRepository accountRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	/* Updating balance for a customer */
	@Override
	public void saveBalance(String accountNumber,double balance) {
		Account account= new Account();
		account=accountRepository.findByAccountNumber(accountNumber);
		account.setBalance(balance);
		accountRepository.save(account);
	}
	
	/* Saving account details of a customer */
	public void saveAccount(CustomerRequestDto customerRequestDtoCustomer) {
	Account account= new Account();
	Customer bankCustomer = new Customer();
	account.setAccountNumber("SBI"+accountNumber++);
	bankCustomer=customerRepository.findCustomerIdByName(customerRequestDtoCustomer.getName());
	account.setCustomerId(bankCustomer.getCustomerId());
	account.setBalance(0);
	accountRepository.save(account);
	
	}
}
