package com.company.app.service;

import com.company.app.Dto.BeneficiaryRequestDto;

public interface BeneficiaryService {

	void addPayee(BeneficiaryRequestDto beneficiaryRequestDto);

}
