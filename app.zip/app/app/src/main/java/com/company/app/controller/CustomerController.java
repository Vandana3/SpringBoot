package com.company.app.controller;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.company.app.Dto.CustomerRequestDto;
import com.company.app.model.Customer;
import com.company.app.service.AccountService;
import com.company.app.service.CustomerService;

import ch.qos.logback.classic.Logger;

@RestController
public class CustomerController {
	
private final Logger LOGGER =(Logger) LoggerFactory.getLogger(CustomerController.class);
@Autowired
CustomerService bankingService;
@Autowired
AccountService accountService;

/* Saving customer and account details */
@PostMapping("/customer")
public void getCustomer(@RequestBody CustomerRequestDto customerRequestDto) {
	bankingService.saveCustomer(customerRequestDto);
	accountService.saveAccount(customerRequestDto);
	
}

/* Get customer details */
@GetMapping("/customer")
public Iterable<Customer> getCustomer() {
	LOGGER.info("Inside get customer");
	return bankingService.getCustomerDetails();
}

/* Customer login validation */
@PostMapping("/login")
public void customerLogin(@RequestBody CustomerRequestDto customerRequestDto) {
	String name=customerRequestDto.getName();
	String password=customerRequestDto.getPassword();
	bankingService.validateCustomer(name,password);
}

}
