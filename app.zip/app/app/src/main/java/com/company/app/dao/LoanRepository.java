package com.company.app.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.app.model.Loan;
@Repository
public interface LoanRepository extends CrudRepository<Loan,Integer>{

}
