package com.company.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.app.service.AccountService;
@RestController
public class AccountController {
	
	@Autowired
	AccountService accountService;
	
	/* Updating the initial balance */
	/*
	 * @PatchMapping("/account/balance/{accountNumber}/{balance}") public void
	 * updateBalance( @PathVariable("accountNumber")String
	 * accountNumber,@PathVariable("balance")double balance) {
	 * accountService.saveBalance(accountNumber,balance); }
	 */
	
	@PatchMapping("/account/balance")
	public void updateBalance( @RequestParam("accountNumber")String accountNumber,@RequestParam("balance")double balance) {
		accountService.saveBalance(accountNumber,balance);
	}
}
