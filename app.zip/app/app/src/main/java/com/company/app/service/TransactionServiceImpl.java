package com.company.app.service;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import com.company.app.Dto.TransactionRequestDto;
import com.company.app.dao.AccountRepository;
import com.company.app.dao.BeneficiaryRepository;
import com.company.app.dao.CustomerRepository;
import com.company.app.dao.TransactionRepository;
import com.company.app.exceptionHandling.AccountNotFoundException;
import com.company.app.exceptionHandling.InsufficientBalanceException;
import com.company.app.exceptionHandling.PayeeNotFoundException;
import com.company.app.model.Account;
import com.company.app.model.Customer;
import com.company.app.model.Beneficiary;
import com.company.app.model.CompositeId;
import com.company.app.model.Transaction;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired 
	CustomerRepository customerRepository;
	@Autowired 
	TransactionRepository transactionRepository;
	
	@Autowired 
	AccountRepository accountRepository;
	
	@Autowired
	BeneficiaryRepository beneficiaryRepository;
	
	/* Saving transaction details */
	@Override
	public void saveTransaction(TransactionRequestDto transactionRequestDto) {
		Transaction transaction1= new Transaction();
		Transaction transaction2 = new Transaction();
		
		Account fromBankAccount= new Account();
		Account toBankAccount= new Account();
		
		fromBankAccount=accountRepository.findByAccountNumber(transactionRequestDto.getFromAccountNumber());
		toBankAccount=accountRepository.findByAccountNumber(transactionRequestDto.getToAccountNumber());
		
		if(fromBankAccount==null||toBankAccount==null) {
			throw new AccountNotFoundException("Account Not Found ");
		}
		
		CompositeId compositeId= new CompositeId();
		compositeId.setFromAccountNumber(fromBankAccount.getAccountNumber());
		compositeId.setBeneficiaryAccountNumber(toBankAccount.getAccountNumber());
		Optional<Beneficiary> beneficiary=beneficiaryRepository.findById(compositeId);
		
		if(!beneficiary.isPresent()) { 
			throw new PayeeNotFoundException("Payee not added");
		}
			
		if(fromBankAccount.getBalance()<transactionRequestDto.getAmount()) {
				throw new InsufficientBalanceException("Insufficient Balance");
		}
				
		transaction1.setAccountNumber(transactionRequestDto.getFromAccountNumber());
		transaction1.setAmount(transactionRequestDto.getAmount());
		transaction1.setDescription(transactionRequestDto.getDescription());
		transaction1.setTransactionType("DEBIT");
		fromBankAccount.setBalance(fromBankAccount.getBalance()-transactionRequestDto.getAmount());
				
		transaction2.setAccountNumber(transactionRequestDto.getToAccountNumber());
		transaction2.setAmount(transactionRequestDto.getAmount());
		transaction2.setDescription("Amount Credited");
		transaction2.setTransactionType("CREDIT");
		toBankAccount.setBalance(toBankAccount.getBalance()+transactionRequestDto.getAmount());
					
		accountRepository.save(fromBankAccount);
		accountRepository.save(toBankAccount);
		transactionRepository.save(transaction1);
		transactionRepository.save(transaction2);
	}
			 
}
