package com.company.app.exceptionHandling;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionController {
   @ExceptionHandler(value = AccountNotFoundException.class)
   public ResponseEntity<Object> exception(AccountNotFoundException exception) {
	   String message=exception.getMessage();
	   
       ErrorResponse error = new ErrorResponse(message, LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   @ExceptionHandler(value=InsufficientBalanceException.class)
   public ResponseEntity<Object> exception(InsufficientBalanceException exception) {
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message, LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   
   @ExceptionHandler(value=InvalidLoginException.class)
   public ResponseEntity<Object> exception(InvalidLoginException exception) {
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message, LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   
   @ExceptionHandler(value=PayeeNotFoundException.class)
   public ResponseEntity<Object> exception(PayeeNotFoundException exception) {
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message, LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   
   @ExceptionHandler(value=PayeeAlreadyExistsException.class)
   public ResponseEntity<Object> exception(PayeeAlreadyExistsException exception) {
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message, LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
   
   @ExceptionHandler(value=NoLoanOptionAvailableException.class)
   public ResponseEntity<Object> exception(NoLoanOptionAvailableException exception) {
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message, LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
}
