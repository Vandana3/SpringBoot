

package com.company.app.model;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity
public class Beneficiary{
	@EmbeddedId
	CompositeId id;
	String beneficiaryName;
	public CompositeId getId() {
		return id;
	}
	public void setId(CompositeId id) {
		this.id = id;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	
}