package com.company.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.app.Dto.CustomerRequestDto;
import com.company.app.dao.AccountRepository;
import com.company.app.dao.CustomerRepository;
import com.company.app.exceptionHandling.InvalidLoginException;
import com.company.app.model.Account;
import com.company.app.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
@Autowired
CustomerRepository customerRepository;
@Autowired
AccountRepository accountRepository;

static int id=1000;

	/* Saving customer details */
	@Override
	public void saveCustomer(CustomerRequestDto customerRequestDto) {
		Customer bankCustomer = new Customer();
		bankCustomer.setAddress(customerRequestDto.getAddress());
		bankCustomer.setDateOfBirth(customerRequestDto.getDateOfBirth());
		bankCustomer.setEmail(customerRequestDto.getEmail());
		bankCustomer.setName(customerRequestDto.getName());
		bankCustomer.setPassword(customerRequestDto.getPassword());
		bankCustomer.setPhoneNo(customerRequestDto.getPhoneNo());
		bankCustomer.setAadhar(customerRequestDto.getAadhar());
		bankCustomer.setCustomerId(id++);
		customerRepository.save(bankCustomer);
		
	}

	/* Validating customer */
	@Override
	public  void validateCustomer(String name, String password) {
		Customer bankCustomer= customerRepository.findBankCustomerByNameAndPassword(name,password);
		if(bankCustomer==null) {
			throw new InvalidLoginException("Invalid username or passowrd");
		}
	}
	
	
	/* Getting all customer details */
	@Override
	public Iterable<Customer> getCustomerDetails() {
		return customerRepository.findAll();
		
	}


	


		
		
	

}
