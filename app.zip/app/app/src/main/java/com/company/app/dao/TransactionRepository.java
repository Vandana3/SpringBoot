package com.company.app.dao;

import org.springframework.data.repository.CrudRepository;

import com.company.app.model.Transaction;

public interface TransactionRepository extends CrudRepository<Transaction,Integer>{

}
