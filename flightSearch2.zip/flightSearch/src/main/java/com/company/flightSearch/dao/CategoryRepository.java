package com.company.flightSearch.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.flightSearch.model.Category;

@Repository
public interface CategoryRepository extends CrudRepository<Category,Integer>{

}
