package com.company.flightSearch.dao;

import java.sql.Date;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.flightSearch.model.Flight;

@Repository
public interface FlightRepository extends CrudRepository<Flight,Integer>{

	Iterable<Flight> findFlightBySourceAndDestinationAndDate(String source, String destination, Date date);

}
