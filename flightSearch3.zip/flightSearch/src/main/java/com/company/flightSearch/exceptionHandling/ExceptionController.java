package com.company.flightSearch.exceptionHandling;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;



@ControllerAdvice
public class ExceptionController {
  
   @ExceptionHandler(value=NoFlightsFoundExeption.class)
   public ResponseEntity<Object> exception(NoFlightsFoundExeption exception) {
	   HttpStatus status;
	   status=HttpStatus.NOT_FOUND;
	   String message=exception.getMessage();
	   ErrorResponse error = new ErrorResponse(message,status.value(), LocalDate.now());
       return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
      
   }
  
}
