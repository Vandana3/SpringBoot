package com.example.flightTicket.exceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
 
@ResponseStatus(HttpStatus.NOT_FOUND)
public class PassengerDetailsRequiredException extends RuntimeException {
	 public PassengerDetailsRequiredException(String exception) {
	        super(exception);
	    }
}
