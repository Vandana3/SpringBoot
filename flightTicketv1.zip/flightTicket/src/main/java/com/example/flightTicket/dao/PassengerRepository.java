package com.example.flightTicket.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.flightTicket.model.CompositeId;
import com.example.flightTicket.model.Passenger;

@Repository
public interface PassengerRepository extends CrudRepository<Passenger,CompositeId>{

}
