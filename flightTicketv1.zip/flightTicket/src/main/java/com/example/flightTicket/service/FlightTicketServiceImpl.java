package com.example.flightTicket.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.example.flightTicket.dto.BookTicketRequestDto;
import com.example.flightTicket.dto.FlightResponseDto;
import com.example.flightTicket.dto.FlightSeatResponseDto;
import com.example.flightTicket.exceptionHandling.ImproperCategoryException;
import com.example.flightTicket.exceptionHandling.NoFlightsFoundException;
import com.example.flightTicket.exceptionHandling.NoSeatsAvailableException;
import com.example.flightTicket.exceptionHandling.PassengerDetailsRequiredException;

@Service
public class FlightTicketServiceImpl implements FlightTicketService{
	@Autowired 
	RestTemplate restTemplate;
	@Override
	public ResponseEntity<Object> bookTicket(BookTicketRequestDto bookTicketRequestDto) {
		
		Boolean bool=false;
		String flightUrl = "http://localhost:8084/flights";
		UriComponentsBuilder flightbuilder = UriComponentsBuilder
		    .fromUriString(flightUrl)
		    .queryParam("source", bookTicketRequestDto.getSource())
		    .queryParam("destination", bookTicketRequestDto.getDestination())
		    .queryParam("date", bookTicketRequestDto.getDate());
		List<HashMap> flightList= new ArrayList<HashMap>();
		flightList  = restTemplate.getForObject(flightbuilder.toUriString(), ArrayList.class);
		if(flightList.isEmpty())throw new NoFlightsFoundException("No flight for your requirement");
		 if(flightList.stream().
		 filter(f->(int)f.get("flightId")==(int)bookTicketRequestDto.getFlightId())
		 .collect(Collectors.toList()).isEmpty()) {throw new NoFlightsFoundException("FlightId not matching");}
		 
		 
		 String seatsUrl="http://localhost:8084/flights/{flightId}/seats";
		 int urlParam=bookTicketRequestDto.getFlightId();
		 UriComponentsBuilder seatbuilder = UriComponentsBuilder
				    .fromUriString(seatsUrl);
		 FlightSeatResponseDto flightSeatResponseDto=restTemplate.getForObject(seatbuilder.buildAndExpand(urlParam).toUri(), FlightSeatResponseDto.class);
		 switch(bookTicketRequestDto.getCategory()) {
		 case "business":
			 if(flightSeatResponseDto.getBusinessSeats()-bookTicketRequestDto.getNumberOfTickets()>=0)bool=true;
			 break;
		 case "economy":
			 if(flightSeatResponseDto.getEconomySeats()-bookTicketRequestDto.getNumberOfTickets()>=0)bool=true;
			 break;
		default:
			throw new ImproperCategoryException("Give proper category");
		 }
		 if(bool==false)throw new NoSeatsAvailableException("No seats available");
		 
		 
		 
		 if(bookTicketRequestDto.getPassenger().size()!=bookTicketRequestDto.getNumberOfTickets()) {
			 throw new PassengerDetailsRequiredException("Enter all passenger details");
		 }
		 
		 String airportUrl="http://localhost:8084/flights/location";
		 UriComponentsBuilder airportbuilder = UriComponentsBuilder
				    .fromUriString(airportUrl)
				    .queryParam("location", bookTicketRequestDto.getSource());
		 String airportName=restTemplate.getForObject(airportbuilder.toUriString(), String.class);
		 System.out.println(airportName);
		 return null;
	}

}
