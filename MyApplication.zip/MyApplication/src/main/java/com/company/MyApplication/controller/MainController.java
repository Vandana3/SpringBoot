package com.company.MyApplication.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.company.MyApplication.model.Employee;
import com.company.MyApplication.model.Loan;

@RestController
public class MainController {
@Autowired 
RestTemplate restTemplate;

/* Getting employee details whose salary is greater than given salary */
@GetMapping("/Employee")
public List<Employee> getEmployees() {
	List<Employee> employee=restTemplate.getForObject("http://Employee/employee/salary?salary=10000",List.class);
	return employee;
}

/* Getting loan details for employees having salary greater than given salary */
@GetMapping("/Loan")
public List<Loan> getLoan() {
	List<Loan> loan=restTemplate.getForObject("http://app/loan?salary=30000",List.class);
	return loan;
}
@PatchMapping("/Balance")
public void updateBalance() {
	restTemplate.patchForObject(null, "http://localhost:8080/account/balance?accountNumber=SBI001&balance=20000", null);
}

}
