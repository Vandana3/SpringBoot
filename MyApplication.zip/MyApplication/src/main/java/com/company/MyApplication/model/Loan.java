package com.company.MyApplication.model;




public class Loan {

Integer id;
double interest;
double tenure;
long principle;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public double getInterest() {
	return interest;
}
public void setInterest(double interest) {
	this.interest = interest;
}
public double getTenure() {
	return tenure;
}
public void setTenure(double tenure) {
	this.tenure = tenure;
}
public long getPrinciple() {
	return principle;
}
public void setPrinciple(long principle) {
	this.principle = principle;
}

}
